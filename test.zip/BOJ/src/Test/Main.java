package Test;

import java.io.*;
import java.util.*;

public class Main {
	public static void main(String[] args) throws IOException {
        FileReader reader = new FileReader("/workspace/BOJ/src/input.txt");
		BufferedReader br = new BufferedReader(reader);
		
		int n = Integer.parseInt(br.readLine());
		
	}
}