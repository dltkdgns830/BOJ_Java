package Bronze_5;

import java.util.Scanner;

public class BOJ_11654 {
    
    public static void main(String[] args) {
        
        Scanner stdIn = new Scanner(System.in);
        
        char input = stdIn.next().charAt(0);
        
        System.out.println((int)input);
    }
}